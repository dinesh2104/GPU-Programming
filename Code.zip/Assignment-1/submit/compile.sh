nvcc -std=c++17 main.cu -o main.out 
